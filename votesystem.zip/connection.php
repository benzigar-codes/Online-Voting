<?php
$connection = new mysqli("localhost", "root", "", "votesystem");
